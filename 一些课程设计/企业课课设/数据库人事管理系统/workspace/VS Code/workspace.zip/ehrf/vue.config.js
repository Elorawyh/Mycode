module.exports = {
    devServer:{
        //处理不了的请求都转交给80端口服务器
        proxy: "http://localhost:80"
    }
}