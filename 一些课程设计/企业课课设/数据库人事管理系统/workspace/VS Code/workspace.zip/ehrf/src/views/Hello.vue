<template>
  <div>
    <h1 style="color: red">{{ message }}</h1>
    <input v-model="message"/>
  </div>
</template>

<script>
//json对象内部定义的就是vue组件的规则
export default {
  // data表示当前组件内部的数据
  data: function () {
    return {
      message: "bbbbb",
    };
  },
};
</script>

<style>
</style>