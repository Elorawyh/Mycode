<template>
  <div>
      <el-menu mode="horizontal" background-color="#545c64" v-bind:router="true">
          <el-menu-item index="/index/user">用户管理</el-menu-item>
          <el-menu-item index="/index/role">角色管理</el-menu-item>
          <el-menu-item index="/index/menu">菜单管理</el-menu-item>
      </el-menu>
    <div>
      <router-view/>
    </div>

  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>