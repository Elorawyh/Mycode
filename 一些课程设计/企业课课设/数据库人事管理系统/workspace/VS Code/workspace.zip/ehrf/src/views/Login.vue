    <template>
  <div>
    <h1>ehr人事管理系统</h1>
    <div class="input-box">
      <el-input  v-model="user.username" placeholder="请输入用户名" />
    </div>
    <div class="input-box">
      <el-input  v-model="user.password" placeholder="请输入密码"  show-password/>
    </div>
    <div class="input-box">
        <el-button type="primary" v-on:click="submitUser">登录</el-button>
        <el-button v-on:click="clearForm">清空</el-button>
    </div>
  </div>
</template>

<script>
export default {
    data:function(){
        return {
            user:{
                username:"",
                password:""
            }
        }
    },
    methods:{
        //clearForm是一个方法，将输入框内容清空
        clearForm:function(){
            this.user.username ="";
            this.user.password = "";
        },
        submitUser:function(){
            //将user的数据提交给后台服务器,
            //post方法接收两个参数，第一个是url，第二个是数据，以json格式提交
            this.$axios.post('/login',this.user).then(resp=>{
                this.$message({
                    type:"success",
                    message:"登录成功"
                });
                //路由到首页,push方法指定跳转的页面地址，其中地址由path属性绝定
                this.$router.push({path:"/index"})
            }).catch(error=>this.$message({
                type:"error",
                message:"登录失败，请重试"
            }))
        }
    }
};
</script>

<style scoped>
.input-box{
    
    margin:0 auto;
    margin-bottom:20px;
    width: 400px;
}
</style>