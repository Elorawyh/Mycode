<template>
  <div>
    <!-- 弹出对话框 -->
    <el-dialog :visible.sync="dialogVisible" :title="formTitle" v-on:close="clearForm">
      <el-form :model="formData" :rules="rules" ref="userForm">
        <el-form-item label="用户名" label-width="100px" prop="username">
          <el-input v-model="formData.username" />
        </el-form-item>
        <el-form-item label="密码" label-width="100px" prop="password">
          <el-input v-model="formData.password" />
        </el-form-item>
        <el-form-item label="姓名" label-width="100px" prop="name">
          <el-input v-model="formData.name" />
        </el-form-item>
        <el-form-item label="联系方式" label-width="100px" prop="phone">
          <el-input v-model="formData.phone" />
        </el-form-item>
        <el-form-item label="角色列表" label-width="100px" prop="roleList">
          <el-select v-model="formData.roleList" multiple>
            <el-option
              v-for="role in roles"
              :key="role.id"
              :value="role.id"
              :label="role.roleName"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div>
        <el-button type="primary" v-on:click="saveUser">确定</el-button>
        <el-button v-on:click="clearForm()">取消</el-button>
      </div>
    </el-dialog>

    <el-button type="success" v-on:click="openNew">新增用户</el-button>
    <el-table :data="userList">
      <!-- 设置具体的数据列 -->
      <el-table-column prop="username" label="用户名"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="phone" label="联系方式"></el-table-column>
      <!-- 自定义列 -->
      <el-table-column>
        <template slot="header" slot-scope="scope">
          <el-input
            placeholder="输入用户名进行查询"
            v-model="usernameQuery"
            v-on:keyup.native.enter="findUsers"
          />
        </template>
        <template slot-scope="scope">
          <el-button type="danger" v-on:click="deleteUser(scope.row)"
            >删除</el-button
          >
          <el-button v-on:click="openEdit(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  created() {
    //去查询userList，向后台查询
    this.findUsers();
    //打开页面后去查询所有的可选角色信息
    this.findAllRoles();
  },
  methods: {
    clearForm(){
      this.$refs['userForm'].resetFields();
      this.dialogVisible = false;
    },
    /**
     * 查询所有的角色信息
     */
    findAllRoles() {
      this.$axios.get("/role/all").then((resp) => {
        this.roles = resp.data;
      });
    },
    /**
     * 更新一条数据
     */
    saveUser() {
      //先验证，验证成功了才能发请求
      this.$refs["userForm"].validate((valid) => {
        //如果结果为真，就触发请求发送
        if (valid) {
          //修改formData中roleList的状态
          let newRoles = [];
          this.formData.roleList.forEach((value) => {
            newRoles.push({ id: value });
          });
          this.formData.roleList = newRoles;

          if (this.formTitle == "新增用户信息") {
            //通过请求提交formData
            this.$axios.post("/user", this.formData).then((resp) => {
              if (resp.data == "insert success") {
                this.$message({
                  type: "success",
                  message: "新增成功",
                });
                //关闭窗口
                this.dialogVisible = false;
                //刷新数据
                this.findUsers();
              }
            });
          } else {
            //通过请求提交formData
            this.$axios.post("/user/update", this.formData).then((resp) => {
              if (resp.data == "update success") {
                this.$message({
                  type: "success",
                  message: "更新成功",
                });
                //关闭窗口
                this.dialogVisible = false;
                //刷新数据
                this.findUsers();
              }
            });
          }
        } else {
          return false;
        }
      });
    },
    openNew() {
      //请空验证的状态
      //设置表单title
      this.formTitle = "新增用户信息";
      this.dialogVisible = true;
      this.formData.id = "";
      this.formData.username = "";
      this.formData.password = "";
      this.formData.name = "";
      this.formData.phone = "";
      //清空角色清单
      this.formData.roleList = [];
    },
    openEdit(row) {
      //请空验证的状
      //设置表单title
      this.formTitle = "更新用户信息";
      this.dialogVisible = true;
      //将这条数据的值设置为formData
      this.formData.id = row.id;
      this.formData.username = row.username;
      this.formData.password = row.password;
      this.formData.name = row.name;
      this.formData.phone = row.phone;
      //加载用户已有的角色清单
      //this.formData.roleList = row.roleList;
      //将从后台获取的某一个用户的rolelist集合中的每一个role的id存入formData中的roleList数组中
      this.formData.roleList = [];
      row.roleList.forEach((role) => {
        this.formData.roleList.push(role.id);
      });
    },
    findUsers() {
      //具体的查询逻辑
      this.$axios
        .post("/user/find", { username: this.usernameQuery })
        .then((resp) => (this.userList = resp.data));
    },
    //row就是要删除的一行数据
    deleteUser(row) {
      alert(JSON.stringify(row));
      //弹出确认框，确认是否删除，如果确认就向后台发出删除请求
      this.$confirm("是否确认删除用户信息？", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        //去删除数据
        this.$axios.delete("/user/" + row.id).then((resp) => {
          if (resp.data == "delete success") {
            //删除成功了，给一个消息提示，并且刷新前台的user信息
            this.$message({
              type: "success",
              message: "删除成功！",
            });
            this.findUsers();
          }
        });
      });
    },
  },
  data() {
    //验证手机规则的方法
    var checkPhone = (rule,value,callback)=>{
      
        if(/^1(?:70\d|(?:9[89]|8[0-24-9]|7[135-8]|66|5[0-35-9])\d|3(?:4[0-8]|[0-35-9]\d))\d{7}$/.test(value)){
          callback();
        }else{
          return callback(new Error("手机号格式非法！"));
        }
    };

    return {
      /* 验证规则对象 */
      rules: {
        username: [
          /* 判定是否为空 */
          { required: true, message: "用户名不能为空", trigger: "blur" },
          /* 判定是否长度在3-8之间 */
          { min: 3, max: 8, message: "用户名长度3-8之间", trigger: "blur" },
        ],
        password:[
           /* 判定是否为空 */
          { required: true, message: "密码不能为空", trigger: "blur" }
        ],
        name:[
          { required: true, message: "姓名不能为空", trigger: "blur" },
          { min: 2, max: 5, message: "姓名长度2-5之间", trigger: "blur" },
        ],
        phone:[
          { required: true, message: "联系方式不能为空", trigger: "blur" },
          {validator:checkPhone,trigger:"blur"}
        ],
        roleList:[
          { required: true, message: "角色不能为空", trigger: "change" }
        ]
      },
      roles: [], //所有可选角色
      formTitle: "",
      formData: {
        id: "",
        username: "",
        password: "",
        name: "",
        phone: "",
        roleList: [],
      },
      usernameQuery: "",
      userList: [],
      dialogVisible: false,
    };
  },
};
</script>

<style>
</style>