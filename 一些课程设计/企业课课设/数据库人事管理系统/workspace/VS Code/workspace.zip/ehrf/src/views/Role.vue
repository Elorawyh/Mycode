<template>
  <div>
    <!-- 弹出对话框 -->
    <el-dialog :visible.sync="dialogVisible" :title="formTitle" v-on:close="clearForm">
      <el-form :model="formData" ref="userForm">
        <el-form-item label="角色名" label-width="100px" prop="roleName">
          <el-input v-model="formData.roleName" />
        </el-form-item>

        <el-form-item label="菜单列表" label-width="100px" prop="menuList">
          <el-select v-model="formData.menuList" multiple>
            <el-option
              v-for="menu in menus"
              :key="menu.id"
              :value="menu.id"
              :label="menu.menuName"
            ></el-option>
          </el-select>
        </el-form-item>

      </el-form>
      <div>
        <el-button type="primary" v-on:click="saveRole">确定</el-button>
        <el-button v-on:click="clearForm()">取消</el-button>
      </div>
    </el-dialog>

    <el-button type="success" v-on:click="openNew">新增角色</el-button>
    <el-table :data="roleList">
      <!-- 设置具体的数据列 -->
      <el-table-column prop="roleName" label="角色名"></el-table-column>
      <!-- 自定义列 -->
      <el-table-column>
        <template slot="header" slot-scope="scope">
          <el-input
            placeholder="输入角色名进行查询"
            v-model="rolenameQuery"
            v-on:keyup.native.enter="findRoles"
          />
        </template>
        <template slot-scope="scope">
          <el-button type="danger" v-on:click="deleteRole(scope.row)"
            >删除</el-button
          >
          <el-button v-on:click="openEdit(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  created() {
    //去查询userList，向后台查询
    this.findRoles();
    //打开页面后去查询所有的可选角色信息
    this.findAllMenus();
  },
  methods: {
  clearForm(){
      this.$refs['userForm'].resetFields();
      this.dialogVisible = false;
    },
    /**
     * 查询所有的角色信息
     */
    findAllMenus() {
      this.$axios.get("/menu/all").then((resp) => {
        this.menus = resp.data;
      });
    },
    /**
     * 更新一条数据
     */
    saveRole() {
          let newMenus = [];
          this.formData.menuList.forEach((value) => {
            newMenus.push({ id: value });
          });
          this.formData.menuList = newMenus;

          if (this.formTitle == "新增角色信息") {
            //通过请求提交formData
            this.$axios.post("/role", this.formData).then((resp) => {
              if (resp.data == "insert success") {
                this.$message({
                  type: "success",
                  message: "新增成功",
                });
                //关闭窗口
                this.dialogVisible = false;
                //刷新数据
                this.findRoles();
              }
            });
          } else {
            //通过请求提交formData
            this.$axios.post("/role/update", this.formData).then((resp) => {
              if (resp.data == "update success") {
                this.$message({
                  type: "success",
                  message: "更新成功",
                });
                //关闭窗口
                this.dialogVisible = false;
                //刷新数据
                this.findRoles();
              }
            });
          }
        },
    openNew() {
      //请空验证的状态
      //设置表单title
      this.formTitle = "新增角色信息";
      this.dialogVisible = true;
      this.formData.id = "";
      this.formData.roleName = "";
      //清空角色清单
      this.formData.menuList = [];
    },
    openEdit(row) {
      //请空验证的状
      //设置表单title
      this.formTitle = "更新角色信息";
      this.dialogVisible = true;
      //将这条数据的值设置为formData
      this.formData.id = row.id;
      this.formData.roleName = row.roleName;
      //加载用户已有的角色清单
      //this.formData.roleList = row.roleList;
      //将从后台获取的某一个用户的rolelist集合中的每一个role的id存入formData中的roleList数组中
      this.formData.menuList = [];
      row.menuList.forEach((menu) => {
        this.formData.menuList.push(menu.id);
      });
    },
    findRoles() {
      //具体的查询逻辑
      this.$axios
        .post("/role/find", { roleName: this.rolenameQuery })
        .then((resp) => (this.roleList = resp.data));
    },
    //row就是要删除的一行数据
    deleteRole(row) {
      alert(JSON.stringify(row));
      //弹出确认框，确认是否删除，如果确认就向后台发出删除请求
      this.$confirm("是否确认删除用户信息？", "警告", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        //去删除数据
        this.$axios.delete("/role/" + row.id).then((resp) => {
          if (resp.data == "delete success") {
            //删除成功了，给一个消息提示，并且刷新前台的user信息
            this.$message({
              type: "success",
              message: "删除成功！",
            });
            this.findRoles();
          }
        });
      });
    },
},
data() {
    return {
        menus: [], //所有可选菜单
        formTitle: "",
        formData: {
            id: "",
            roleName: "",
            menuList: [],
        },
        rolenameQuery: "",
        roleList: [],
        dialogVisible: false,
    };
},
};
</script>

<style>

</style>