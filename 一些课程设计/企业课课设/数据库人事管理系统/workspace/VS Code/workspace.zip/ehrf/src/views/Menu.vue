<template>
  <div>

    <el-dialog :visible.sync="dialogVisible" :title="formTitle" v-on:close="clearForm">
      <el-form :model="formData" ref="userForm">
        <el-form-item label="菜单名" label-width="100px" prop="menuName">
          <el-input v-model="formData.menuName" />
        </el-form-item>
        
        <el-form-item label="url" label-width="100px" prop="url">
          <el-input v-model="formData.url" />
        </el-form-item>
      </el-form>

      <div>
        <el-button type="primary" v-on:click="saveMenu">确定</el-button>
        <el-button v-on:click="clearForm()">取消</el-button>
      </div>
    </el-dialog>

    <el-button type="success" v-on:click="openNew">新增菜单</el-button>
    <el-table :data="MenuList">
      <!-- 设置具体的数据列 -->
      <el-table-column prop="menuName" label="页面名"></el-table-column>
      <!-- 自定义列 -->
      <el-table-column>
        <template slot="header" slot-scope="scope">
          <el-input
            placeholder="输入菜单名进行查询"
            v-model="menunameQuery"
            v-on:keyup.native.enter="findMenus"
          /> 
        </template>
        <template slot-scope="scope">
          <el-button type="danger" v-on:click="deleteMenu(scope.row)"
            >删除</el-button
          >
          <el-button v-on:click="openEdit(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
    created() {
        this.findMenus();
    },
    methods: {
        clearForm(){
            this.$refs['userForm'].resetFields();
            this.dialogVisible = false;
        },
        saveMenu() {
            if (this.formTitle == "新增菜单信息") {
                //通过请求提交formData
                this.$axios.post("/menu", this.formData).then((resp) => {
                if (resp.data == "insert success") {
                    this.$message({
                    type: "success",
                    message: "新增成功",
                    });
                    //关闭窗口
                    this.dialogVisible = false;
                    //刷新数据
                    this.findMenus();
                }
                });
            } else {
                //通过请求提交formData
                this.$axios.post("/menu/update", this.formData).then((resp) => {
                if (resp.data == "update success") {
                    this.$message({
                    type: "success",
                    message: "更新成功",
                    });
                    //关闭窗口
                    this.dialogVisible = false;
                    //刷新数据
                    this.findMenus();
                }
                });
            }
            },
        openNew() {
        //请空验证的状态
        //设置表单title
        this.formTitle = "新增菜单信息";
        this.dialogVisible = true;
        this.formData.id = "";
        this.formData.menuName = "";
        this.formData.url = "";
        },
        openEdit(row) {
        //请空验证的状
        //设置表单title
        this.formTitle = "更新菜单信息";
        this.dialogVisible = true;
        //将这条数据的值设置为formData
        this.formData.id = row.id;
        this.formData.menuName = row.menuName;
        this.formData.url = row.url;
        },
        findMenus() {
        //具体的查询逻辑
        this.$axios
            .post("/menu/find", { menuName: this.menunameQuery })
            .then((resp) => (this.MenuList = resp.data));
        },
        //row就是要删除的一行数据
        deleteMenu(row) {
        alert(JSON.stringify(row));
        //弹出确认框，确认是否删除，如果确认就向后台发出删除请求
        this.$confirm("是否确认删除用户信息？", "警告", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning",
        }).then(() => {
            //去删除数据
            this.$axios.delete("/menu/" + row.id).then((resp) => {
            if (resp.data == "delete success") {
                //删除成功了，给一个消息提示，并且刷新前台的user信息
                this.$message({
                type: "success",
                message: "删除成功！",
                });
                this.findMenus();
            }
            });
        });
        },
    },
    data() {
        return {
            formTitle: "",
            formData: {
                id: "",
                menuName: "",
                url: "",
            },
            menunameQuery: "",
            MenuList: [],
            dialogVisible: false,
        };
    }
};
</script>

<style>

</style>